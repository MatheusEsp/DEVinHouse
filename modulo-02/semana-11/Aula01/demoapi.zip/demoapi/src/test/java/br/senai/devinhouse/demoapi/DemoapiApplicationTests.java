package br.senai.devinhouse.demoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
