package br.senai.devinhouse.ExSemanal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExSemanalApplicationTests {

	@Test
	void contextLoads() {
	}

}
