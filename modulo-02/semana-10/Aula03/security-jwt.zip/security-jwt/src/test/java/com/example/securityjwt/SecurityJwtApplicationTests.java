package com.example.securityjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
