package com.example.securityver5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityVer5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
